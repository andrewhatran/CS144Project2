# 1. close, 13129
SELECT COUNT(*)
FROM User;

# 2. ok

SELECT COUNT(*)
FROM Item i JOIN User u on i.Seller = u.Username
WHERE BINARY u.Location = "New York";

# 3. 1
SELECT COUNT(*) FROM
(SELECT COUNT(*) FROM Item i, Category c
where i.ItemID = c.ItemID 
GROUP BY i.ItemID
HAVING COUNT(Category) = 4
) a;

# 4 ok
SELECT i.ItemID 
FROM Item i JOIN Bid b on i.ItemID = b.ItemID
WHERE i.currently = (
	SELECT MAX(currently)
	FROM Item
	WHERE ends > '2001-12-20 00:00:01' AND NumberOfBids > 0
);

# 5 7022
SELECT COUNT(*) FROM User u JOIN Item i
WHERE i.Seller = u.Username AND u.Rating >1000;

# 6 13791
SELECT COUNT(*)
FROM Item i JOIN Bid b
ON i.Seller = b.Username;


# 7. ok
SELECT COUNT(DISTINCT Category)
FROM (
SELECT c.ItemID
FROM Category c, Item i, Bid b
WHERE c.ItemID = i.ItemID AND i.ItemID = b.ItemID AND amount > 100
GROUP BY b.ItemID
) a, Category cb
WHERE a.ItemID = cb.ItemID