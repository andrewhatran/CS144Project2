CS 144 Project 2

Karen Zhang (204 481 438)
Andrew Tran (004 188 159)

1.

Item( ItemID, Name, UserID, Buy_Price, First_Bid, Currently, Number_of_Bids, Started, Ends, Description) 
	Primary Key: ItemID


Category(ItemID, Category)


Bid(Bidder, ItemID, Time, Amount)
	Primary Key: Bidder, ItemID, Time


User(UserID, Rating, Location, Country)
	Primary Key: UserID


2. Yes
3. Yes