#!/bin/bash
mysql cs144 < drop.sql
mysql cs144 < create.sql

ant clean
ant
ant run-all

mysql cs144 < load.sql
rm *.dat